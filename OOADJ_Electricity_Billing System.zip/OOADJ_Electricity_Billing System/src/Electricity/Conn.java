package Electricity;

import java.sql.*;

public class Conn {
    private Connection c;
    public Statement s;

    public Conn() {
        try {
            // Load the MySQL JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Connect to the database
            String url = "jdbc:mysql://localhost:3306/project2";
            String username = "root";
            String password = "Jellyfish@123";
            c = DriverManager.getConnection(url, username, password);
            s = c.createStatement();

            // Print connection status
            System.out.println("MySQL connection established successfully.");

            // You can perform database operations here...
        } catch (ClassNotFoundException | SQLException e) {
            // Print connection error
            System.err.println("Failed to connect to MySQL database:");
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        // Test the MySQL connection
        new Conn();
    }
}